const MENU_ID = "media2tabs-image";

function createMenu() {
    chrome.contextMenus.removeAll(() => {
        chrome.contextMenus.create({
            id: MENU_ID,
            title: "Media2Tabs",
            contexts: ["image"]
        });
    });
}

chrome.runtime.onInstalled.addListener(createMenu);
chrome.runtime.onStartup.addListener(createMenu);

chrome.contextMenus.onClicked.addListener((info, tab) => {

    if (info.menuItemId !== MENU_ID) return;
    if (!tab?.id) return;

    chrome.tabs.sendMessage(tab.id, { action: "collectMedia" }, (response) => {

        const urls = response?.urls || [];

        if (!urls.length) return;

        chrome.windows.create({ url: urls[0] }, (win) => {

            for (let i = 1; i < urls.length; i++) {
                chrome.tabs.create({
                    windowId: win.id,
                    url: urls[i]
                });
            }

        });

    });

});