console.log("Media2Tabs loaded");

const MEDIA_EXTENSIONS = [
    "jpg", "jpeg", "png", "gif", "webp", "avif", "bmp", "svg",
    "mp4", "webm"
];

function isMediaUrl(url) {
    if (!url) return false;

    try {
        const clean = url.split("?")[0].split("#")[0].toLowerCase();
        return MEDIA_EXTENSIONS.some(ext => clean.endsWith("." + ext));
    } catch {
        return false;
    }
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {

    if (msg?.action === "collectMedia") {

        const urls = Array.from(document.querySelectorAll("a[href]"))
            .map(a => a.href)
            .filter(isMediaUrl);

        sendResponse({ urls: [...new Set(urls)] });
    }

    return true;
});